# Projeto BDD – Cadastro de Livro

## Como rodar

1. Instale as dependências:
```
npm install
```

2. Execute os testes:
```
npm test
```

Este projeto utiliza Cucumber.js para testes BDD.
